/* Animal Care App Overview:

  Features:
  1. Pet Shop Finder:
     - Users can find pet shops with product details.
     - Option to search for specific pet shops.
     - View available food shops with image URLs.
     - Navigate to specific pet shop pages (e.g., Pet Corner) to view product images and prices.

  2. Adoption:
     - Create adoption posts.
     - View available adoption posts with pet stories and images.
     - Contact owners through provided options.

  3. Foster Home Finder:
     - View nearby foster homes for pets.
     - Option to share location for personalized results.
     - View home details, services, and contact information.
     - Users can become foster parents by creating posts with service details.

  4. Pet Care Information:
     - Information on common diseases and symptoms.
     - First aid instructions for emergencies.
     - Vaccination schedules and information.

  5. Contact with Vet:
     - Find available online veterinarians.
     - Book appointments with various payment options.
     - Contact vets via video call, call, or text after approval.

  6. Search Animal Hospital:
     - Locate nearby animal hospitals based on user's location.

  7. Donation:
     - Create donation posts for non-profit organizations.
     - Verify details before donations are publicized.
     - Seek help for street animals through posts.

  Navigation:
  - Users log in to the app and are directed to a page with feature buttons.
  - Each feature button leads to a dedicated page for that feature.
  - Users can navigate back to the main page or explore other features from any feature page.

  Additional Notes:
  - Admin verification required for certain actions (e.g., donations).
  - Option for users to seek assistance for street animals.
now write code for the main page by keep this in mind we will have a
log in page containing email password and sing up option with google and apple .
then we will have a home page for the user whrere they can see  the features button
and for all features there will be separate
page so now just do the code for main.dart file that can connect all pages
 */

//now lets make main.dart file code there will be a Home page and log in page as base
// and then we will make separate pages for each feature

/*
import 'package:flutter/material.dart';
import 'package:untitled/screen/loginpage.dart';
import 'package:untitled/screen/home page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Animal Care App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
    );
  }
}


this the main .dart code
 */
import 'package:flutter/material.dart';
import 'package:untitled/screen/Homepage.dart'; // Import the home page

class LoginPage extends StatelessWidget {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Animal Care App'),
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.pink[50], // Baby pink background color
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 250,
                child: Image.network(
                  'https://tse2.mm.bing.net/th?id=OIP.xMjk-f7661WMqhtFHiQuZwHaEK&pid=Api&P=0&h=220', // Replace with actual URL
                  fit: BoxFit.contain,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Log in',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: 300, // Width of the text fields
                child: TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    filled: true,
                    fillColor: Colors.white, // White background color for text field
                  ),
                ),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: 300, // Width of the text fields
                child: TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    filled: true,
                    fillColor: Colors.white, // White background color for text field
                  ),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Implement your login logic here
                  String email = _emailController.text;
                  String password = _passwordController.text;
                  // For simplicity, let's just print the credentials
                  print('Email: $email');
                  print('Password: $password');
                  // Navigate to home page after successful login
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()), // Navigate to home page
                  );
                },
                child: Text('Log in'),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      // Implement sign up with Google logic
                      print('Signing up with Google');
                    },
                    icon: Icon(Icons.account_circle), // Placeholder icon
                    label: Text('Sign up with Google'),
                  ),
                  SizedBox(width: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Implement sign up with Apple logic
                      print('Signing up with Apple');
                    },
                    icon: Icon(Icons.account_circle), // Placeholder icon
                    label: Text('Sign up with Apple'),
                  ),
                ],
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  // Navigate to sign up page
                  print('Navigating to sign up page');
                },
                child: Text(
                  "Haven't signed up yet? Sign up now!",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.blue,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
